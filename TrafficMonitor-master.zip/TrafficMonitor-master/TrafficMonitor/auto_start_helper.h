#pragma once

bool is_auto_start_task_active_for_this_user(std::wstring* path);
bool create_auto_start_task_for_this_user(bool runElevated);
bool delete_auto_start_task_for_this_user();
