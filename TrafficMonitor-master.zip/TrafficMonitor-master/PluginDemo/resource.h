﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 PluginDemo.rc 使用
//
#define IDD_DIALOG1                     101
#define IDD_OPTIONS_DIALOG              101
#define IDS_PLUGIN_NAME                 103
#define IDS_PLUGIN_DESCRIPTION          104
#define IDS_TIME                        105
#define IDS_DATE                        106
#define IDS_CUSTOM_DRAW_ITEM            107
#define IDC_SHOW_SECOND_CHECK           1001
#define IDC_SHOW_LABEL_CHECK            1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
